package cn.edu.scau.sec.tangxuexi.abstractFactory.interfaceClass;

public interface AppleBrand extends Brand{
	public static final String name = "苹果";

}

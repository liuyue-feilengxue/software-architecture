package cn.edu.scau.sec.tangxuexi.factory.bean;

public interface ConsumerElectronics {
	void recreation();

}

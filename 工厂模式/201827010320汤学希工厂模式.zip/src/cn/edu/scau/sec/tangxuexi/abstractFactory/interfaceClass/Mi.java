package cn.edu.scau.sec.tangxuexi.abstractFactory.interfaceClass;

public interface Mi extends Brand{
	static final String brandName = "小米";

}

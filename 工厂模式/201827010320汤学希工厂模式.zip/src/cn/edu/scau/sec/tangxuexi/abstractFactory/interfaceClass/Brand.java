package cn.edu.scau.sec.tangxuexi.abstractFactory.interfaceClass;

public interface Brand{

}

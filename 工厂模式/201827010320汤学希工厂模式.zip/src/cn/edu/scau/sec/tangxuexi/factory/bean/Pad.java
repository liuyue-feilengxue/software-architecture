package cn.edu.scau.sec.tangxuexi.factory.bean;

public class Pad implements ConsumerElectronics{

	@Override
	public void recreation() {
		System.out.println("使用平板娱乐");
		
	}

}

package cn.edu.scau.sec.tangxuexi.abstractFactory.interfaceClass;

public interface Huawei extends Brand{
	static final String brandName = "华为";
}

package cn.edu.scau.sec.tangxuexi.abstractFactory.interfaceClass;

public interface MiBrand extends Brand{
	public static final String name = "小米";

}

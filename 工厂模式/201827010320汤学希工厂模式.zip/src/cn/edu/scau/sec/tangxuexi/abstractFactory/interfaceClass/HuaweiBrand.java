package cn.edu.scau.sec.tangxuexi.abstractFactory.interfaceClass;

public interface HuaweiBrand extends Brand{
	public static final String name = "华为";
}

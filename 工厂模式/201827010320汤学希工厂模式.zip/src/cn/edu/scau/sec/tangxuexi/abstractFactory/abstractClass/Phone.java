package cn.edu.scau.sec.tangxuexi.abstractFactory.abstractClass;

public abstract class Phone extends ConsumerElectronics{
	protected String productName = "手机";
}
package cn.edu.scau.sec.tangxuexi.abstractFactory.abstractClass;

public abstract class ConsumerElectronics {
	abstract public void recreation();

}

package cn.edu.scau.sec.tangxuexi.factory.bean;

public class Phone implements ConsumerElectronics{

	@Override
	public void recreation() {
		System.out.println("使用手机娱乐");
		
	}

}
